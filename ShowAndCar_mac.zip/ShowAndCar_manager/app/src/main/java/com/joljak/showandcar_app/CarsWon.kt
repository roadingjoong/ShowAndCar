package com.joljak.showandcar_app

data class CarsWon(
    val heading: String,
    val image: String,
    val carzong: String,
    val brand: String,
    val oil: String,
    val content: String,
    val price: Long
)