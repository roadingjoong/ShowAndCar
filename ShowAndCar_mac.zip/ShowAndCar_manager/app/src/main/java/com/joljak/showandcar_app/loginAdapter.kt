package com.joljak.showandcar_app

data class loginAdapter(
    val name: String,
    val email: String,
    val password: String,
    val tel: Int,
    val gender: String
)